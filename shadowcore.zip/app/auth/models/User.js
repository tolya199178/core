

'use strict';

angular.module('app.auth').factory('User', ['$http', '$q', 'ServerURL', function ($http, $q, ServerURL) {
        return {

        };
}]);

